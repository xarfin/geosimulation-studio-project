import numpy as np, pandas as pd, geopandas as gpd, rasterio, matplotlib, json
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from rasterio.plot import plotting_extent
PKG='/home/claude/zipx/4.1 Area, Massing, Cesium/qgis/Study_Area_Package.gpkg'
sa=gpd.read_file(PKG,layer='Study Area'); water=gpd.read_file(PKG,layer='Water_WTD')
dev=gpd.read_file('/root/.claude/uploads/916c34ab-de61-51fc-8d7f-6dc8ccdec69c/ab3ec972-doc.geojson').to_crs(28992); DEV=dev.union_all()
CLEAR=gpd.read_file('/home/claude/designs/design_A/gis/design.gpkg',layer='building_clearances').union_all()
ex=gpd.read_file('existing_buildings.gpkg'); exk=ex[~(ex.intersects(CLEAR)&(ex.intersection(CLEAR).area>0.5*ex.area))]
D={k:{l:gpd.read_file(f'design_{k}.gpkg',layer=l) for l in ['buildings','surfaces','trees']} for k in 'AB'}
SC=['baseline','design_A','design_B']; LBL={'baseline':'Baseline (existing)','design_A':'Design A – public connections','design_B':'Design B – connected park'}
plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False})
xb=dev.total_bounds+np.array([-70,-70,70,70])
def blds(a,sc):
    (ex if sc=='baseline' else exk).plot(ax=a,color='#333',lw=0)
    if sc!='baseline': D[sc[-1]]['buildings'].plot(ax=a,color='#333',lw=0)
def rd(p):
    with rasterio.open(p) as r: return r.read(1),plotting_extent(r)
def zoom(a): a.set_xlim(xb[0],xb[2]); a.set_ylim(xb[1],xb[3]); a.set_axis_off()
# 1 layouts
COL={'park':'#74c476','edge_landscape':'#a1d99b','existing_route':'#bdbdbd','paths':'#fdd0a2','flexible_space':'#dadaeb','sports':'#fd8d3c','sports_apron':'#fdae6b','retained_building_ground':'#969696','water_exclusion':'#c6dbef','green_roofs':'#31a354'}
fig,ax=plt.subplots(1,2,figsize=(15,4.6),layout='constrained')
for a,k in zip(ax,'AB'):
    s=D[k]['surfaces']; water.plot(ax=a,color='#e3edf5',lw=0)
    for c,col in COL.items():
        if c!='green_roofs': s[s.surface==c].plot(ax=a,color=col,lw=0)
    D[k]['buildings'].plot(ax=a,color='#555',lw=0); s[s.surface=='green_roofs'].plot(ax=a,color=COL['green_roofs'],lw=0,alpha=.9)
    gpd.GeoSeries(D[k]['trees'].geometry.buffer(D[k]['trees'].crown_radius_m)).plot(ax=a,color='#006d2c',lw=0,alpha=.8)
    exk.plot(ax=a,color='#333',lw=0); dev.boundary.plot(ax=a,color='#d1495b',lw=1.2); zoom(a); a.set_title(LBL['design_'+k],loc='left',fontweight='bold')
fig.legend(handles=[Patch(color=v,label=k.replace('_',' ')) for k,v in COL.items()]+[Patch(color='#555',label='building'),Patch(color='#006d2c',label='new tree')],loc='outside lower center',ncol=6,frameon=False)
plt.savefig('out/fig_AB_layouts.png',dpi=130,bbox_inches='tight'); plt.savefig('report/figures/morph_layouts.pdf',bbox_inches='tight'); plt.close()
# 2 SVF zoom: buildings only / buildings+trees
fig,ax=plt.subplots(2,3,figsize=(16,7.2),layout='constrained')
for j,sc in enumerate(SC):
    for i,(pre,t) in enumerate([('svfb','buildings only'),('svf','buildings + trees')]):
        d,e=rd(f'out/{pre}_{sc}.tif'); a=ax[i,j]; water.plot(ax=a,color='#e3edf5',lw=0)
        im=a.imshow(d,extent=e,cmap='Blues_r',vmin=0,vmax=1); blds(a,sc); dev.boundary.plot(ax=a,color='#d1495b',lw=1.2); zoom(a)
        a.set_title(f'{LBL[sc]}\nSVF, {t}',loc='left',fontsize=13,fontweight='bold' if i==0 else 'normal')
fig.colorbar(im,ax=ax,shrink=.6,label='Sky View Factor at 1.5 m (0 = enclosed, 1 = open)')
plt.savefig('out/fig_AB_svf_zoom.png',dpi=130,bbox_inches='tight'); plt.savefig('report/figures/morph_svf.pdf',dpi=220,bbox_inches='tight'); plt.close()
# 3 SVF change vs baseline (buildings only) – shows reach beyond site
fig,ax=plt.subplots(1,2,figsize=(14,5.2),layout='constrained'); b0,e=rd('out/svfb_baseline.tif')
for a,sc in zip(ax,SC[1:]):
    d,_=rd(f'out/svfb_{sc}.tif'); water.plot(ax=a,color='#e3edf5',lw=0)
    im=a.imshow(d-b0,extent=e,cmap='RdBu',vmin=-.3,vmax=.3); blds(a,sc); dev.boundary.plot(ax=a,color='#d1495b',lw=1.2); sa.boundary.plot(ax=a,color='#555',lw=.6)
    a.set_axis_off(); a.set_title(f'{LBL[sc]}: ΔSVF vs baseline',loc='left',fontsize=13,fontweight='bold')
fig.colorbar(im,ax=ax,shrink=.7,label='ΔSVF (red = more enclosed, blue = more open)')
plt.savefig('out/fig_AB_svf_change.png',dpi=130,bbox_inches='tight'); plt.savefig('report/figures/morph_svf_change.pdf',dpi=220,bbox_inches='tight'); plt.close()
# 4 H/W zoom
fig,ax=plt.subplots(1,3,figsize=(16,3.8),layout='constrained')
for a,sc in zip(ax,SC):
    d,e=rd(f'out/hw_{sc}.tif'); im=a.imshow(d,extent=e,cmap='Oranges',vmin=0,vmax=3); blds(a,sc); dev.boundary.plot(ax=a,color='#d1495b',lw=1.2); zoom(a); a.set_title(LBL[sc],loc='left',fontsize=13,fontweight='bold')
fig.colorbar(im,ax=ax,shrink=.8,label='H/W (height ÷ 2 × distance)')
plt.savefig('out/fig_AB_hw_zoom.png',dpi=130,bbox_inches='tight'); plt.savefig('report/figures/morph_hw.pdf',dpi=220,bbox_inches='tight'); plt.close()
# 5 indicator bars
df=pd.read_csv('out/indicators.csv'); d=df[df.zone=='development_site'].set_index('scenario').loc[SC]
d['homes']=[0]+[int(round((D[k]['buildings'].query("use=='residential'").area*np.round(D[k]['buildings'].query("use=='residential'").height/3)).sum()*0.8/75)) for k in 'AB']
d.to_csv('out/indicators_devsite_AB.csv')
K=[('GSI','Building coverage (GSI)'),('FSI','Floor space index (FSI)'),('OSR','Open space ratio (OSR)'),('height_mean_m','Mean height (m)'),
   ('SVF_mean_buildings','Mean SVF, buildings only'),('SVF_mean','Mean SVF, buildings + trees'),('HW_median','Median H/W near buildings'),
   ('green_share','Green share (ground + canopy)'),('landuse_mix_entropy','Land-use mix (0–1)')]
cols=['#9aa0a6','#2a6f97','#61a5c2']
fig,ax=plt.subplots(3,3,figsize=(12,8.5))
for a,(k,t) in zip(ax.flat,K):
    v=d[k].values; a.bar(['Baseline','A','B'],v,color=cols,width=.6)
    for i,x in enumerate(v): a.text(i,x,f'{x:.2f}' if x<10 else f'{x:.0f}',ha='center',va='bottom',fontsize=8)
    a.set_title(t,loc='left',fontsize=10); a.grid(axis='y',color='#eee'); a.set_axisbelow(True); a.tick_params(length=0)
fig.suptitle('Development site: morphology indicators, baseline vs designs A and B',x=.02,ha='left',fontsize=11)
plt.tight_layout(); plt.savefig('out/fig_AB_indicators.png',dpi=130,bbox_inches='tight'); plt.savefig('report/figures/morph_indicators.pdf',bbox_inches='tight'); plt.close()
pd.set_option('display.width',250); print(d.T.to_string())
