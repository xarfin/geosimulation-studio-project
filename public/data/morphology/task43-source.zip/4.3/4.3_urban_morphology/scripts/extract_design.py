"""Extract a CA design (A/B) from its Cesium package (tileset.json + design.glb) into GIS layers, EPSG:28992.
Needed because only the Cesium package differs between design_A and design_B uploads."""
import sys, json, numpy as np, trimesh, pyproj, geopandas as gpd
from shapely.geometry import Polygon, Point
from shapely.ops import unary_union
folder, out = sys.argv[1], sys.argv[2]
T=np.array(json.load(open(f'{folder}/tileset.json'))['root']['transform']).reshape(4,4).T
tr=pyproj.Transformer.from_crs(4978,28992,always_xy=True)
sc=trimesh.load(f'{folder}/design.glb')
def world(g,M):
    v=trimesh.transformations.transform_points(g.vertices,M)
    p=np.c_[v[:,0],-v[:,2],v[:,1],np.ones(len(v))]@T.T
    x,y,_=tr.transform(p[:,0],p[:,1],p[:,2]); return np.c_[x,y], v[:,1]
surf,bld,trees=[],[],[]
for n in sc.graph.nodes_geometry:
    M,gn=sc.graph[n]; g=sc.geometry[gn]; cls=n.rstrip('0123456789_-.') ; xy,z=world(g,M)
    if cls=='illustrative_tree_crowns':
        g=g.copy(); g.merge_vertices(merge_tex=True,merge_norm=True)
        for c in g.split(only_watertight=False):
            cxy,cz=world(c,M); r=(np.ptp(cxy[:,0])+np.ptp(cxy[:,1]))/4
            trees.append(dict(height_top_nap=cz.max(),crown_radius_m=round(r,2),geometry=Point(cxy.mean(0))))
        continue
    if cls=='illustrative_tree_trunks': continue
    nz=g.face_normals[:,1]  # glTF y-up: upward faces
    up=[t for t,k in zip(g.faces,nz) if k>0.9]
    polys=[Polygon(xy[t]).buffer(0.01) for t in up if Polygon(xy[t]).area>1e-4]
    if not polys: continue
    geom=unary_union(polys).buffer(-0.01)
    if cls in ('residential','indoor_sports'):
        base=z.min(); bld.append(dict(name=n,use=cls,base_nap=round(base,2),roof_nap=round(z.max(),2),height=round(z.max()-base,2),geometry=geom))
    else: surf.append(dict(surface=cls,top_nap=round(z.max(),2),geometry=geom))
B=gpd.GeoDataFrame(bld,crs=28992); S=gpd.GeoDataFrame(surf,crs=28992).dissolve('surface',aggfunc='max').reset_index(); Tr=gpd.GeoDataFrame(trees,crs=28992)
B['footprint_m2']=B.area.round(); S['area_m2']=S.area.round()
B.to_file(out,layer='buildings',driver='GPKG'); S.to_file(out,layer='surfaces',driver='GPKG'); Tr.to_file(out,layer='trees',driver='GPKG')
print(B.drop(columns='geometry').to_string()); print(S[['surface','area_m2']].to_string()); print(len(Tr),'trees')
