import pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
df=pd.read_csv('out/indicators.csv'); SC=['baseline','design_A','design_B']
K=[('GSI','Building coverage (GSI)','{:.2f}'),('FSI','Floor space index (FSI)','{:.2f}'),('OSR','Open space ratio (OSR)','{:.2f}'),
   ('height_mean_m','Mean height (m)','{:.0f}'),('SVF_mean_buildings','SVF, buildings only','{:.2f}'),('SVF_mean','SVF, buildings + trees','{:.2f}'),
   ('HW_median','Median H/W','{:.2f}'),('green_share','Green share','{:.1%}'),('landuse_mix_entropy','Land-use mix (0–1)','{:.2f}')]
cols=['#9aa0a6','#2a6f97','#61a5c2']
for zone,name in [('development_site','morph_indicators_site'),('study_area','morph_indicators_study')]:
    d=df[df.zone==zone].set_index('scenario').loc[SC]
    fig,ax=plt.subplots(3,3,figsize=(12,8.2))
    for a,(k,t,fmt) in zip(ax.flat,K):
        v=d[k].values; a.bar(['Baseline','A','B'],v,color=cols,width=.6); a.set_ylim(0,max(v)*1.18)
        for i,x in enumerate(v): a.text(i,x,fmt.format(x),ha='center',va='bottom',fontsize=10)
        a.set_title(t,loc='left',fontsize=12); a.grid(axis='y',color='#eee'); a.set_axisbelow(True); a.tick_params(length=0)
        if k=='green_share': a.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1,0))
    plt.tight_layout(); plt.savefig(f'report/figures/{name}.pdf',bbox_inches='tight'); plt.savefig(f'out/{name}.png',dpi=130,bbox_inches='tight'); plt.close()
