# Web-ready layers for CesiumJS: coloured SVF overlays (EPSG:4326 PNG + rectangle) and building GeoJSON with heights
import numpy as np, rasterio, json, geopandas as gpd, matplotlib
from rasterio.warp import calculate_default_transform, reproject, Resampling
from matplotlib import cm
from PIL import Image
meta={}
for sc in ['baseline','design_A','design_B']:
    for nm in ['svf','svfb','hw']:
        with rasterio.open(f'out/{nm}_{sc}.tif') as s:
            tf,w,h=calculate_default_transform(s.crs,'EPSG:4326',s.width,s.height,*s.bounds)
            d=np.full((h,w),np.nan,'float32'); reproject(rasterio.band(s,1),d,src_transform=s.transform,src_crs=s.crs,dst_transform=tf,dst_crs='EPSG:4326',resampling=Resampling.bilinear,src_nodata=np.nan,dst_nodata=np.nan)
        v=np.clip(d/3,0,1) if nm=='hw' else d   # H/W shown 0..3
        rgba=(matplotlib.colormaps['Oranges' if nm=='hw' else 'Blues_r'](np.nan_to_num(v))*255).astype('uint8'); rgba[...,3]=np.where(np.isfinite(d),210,0)
        Image.fromarray(rgba).save(f'out/cesium/{nm}_{sc}.png',optimize=True)
        meta[f'{nm}_{sc}']=dict(west=tf.c,north=tf.f,east=tf.c+tf.a*w,south=tf.f+tf.e*h)
json.dump(meta,open('out/cesium/overlays_rectangles.json','w'),indent=1)
import pandas as pd
ex=gpd.read_file('existing_buildings.gpkg')
CLEAR=gpd.read_file('/home/claude/designs/design_A/gis/design.gpkg',layer='building_clearances').union_all()
ex['cleared_in_designs']=ex.intersects(CLEAR)&(ex.intersection(CLEAR).area>0.5*ex.area)
ex[['gml_id','height','cleared_in_designs','geometry']].to_crs(4326).to_file('out/cesium/buildings_existing.geojson',driver='GeoJSON')
for k in 'AB':
    b=gpd.read_file(f'design_{k}.gpkg',layer='buildings'); b['design']=k; b[['design','name','use','height','geometry']].to_crs(4326).to_file(f'out/cesium/buildings_design_{k}.geojson',driver='GeoJSON')
print('ok')
