"""4.3 Urban morphology indicators for baseline and massing options O1-O5.
Inputs (EPSG:28992): existing LoD1 buildings, trees, BAG/BGT GeoPackage, development site, proposed massing.
Outputs: out/indicators.csv, out/svf_<scenario>.tif, out/hw_<scenario>.tif"""
import numpy as np, pandas as pd, geopandas as gpd, rasterio, json
from rasterio.features import rasterize
from rasterio.transform import from_origin
from scipy import ndimage
from shapely.affinity import translate
from shapely.geometry import box

PKG='/home/claude/zipx/4.1 Area, Massing, Cesium/qgis/Study_Area_Package.gpkg'
DEV='/root/.claude/uploads/916c34ab-de61-51fc-8d7f-6dc8ccdec69c/ab3ec972-doc.geojson'
RES=1.0; FLOOR_H=3.0; OBS_H=1.5; R_MAX=150; N_AZ=36
O1_SHIFT=(-111.07,21.47)  # O1 origin is offset in Rhino; shift derived from O1's identical towers inside O4 (IoU = 1.0)

sa=gpd.read_file(PKG,layer='Study Area').union_all()
dev=gpd.read_file(DEV).to_crs(28992).union_all()
water=gpd.read_file(PKG,layer='Water_WTD').union_all()
green=gpd.read_file(PKG,layer='Green_BTD'); green=green[green.eind_registratie.isna()] if 'eind_registratie' in green else green
green=green.union_all()
bag=gpd.read_file(PKG,layer='Buildings_BAG')
ex=gpd.read_file('existing_buildings.gpkg')
trees=gpd.read_file('trees.gpkg')
CLEAR=gpd.read_file('/home/claude/designs/design_A/gis/design.gpkg',layer='building_clearances').union_all()
D={k:{l:gpd.read_file(f'design_{k}.gpkg',layer=l) for l in ['buildings','surfaces','trees']} for k in 'AB'}
# --- BAG use -> floor-area weights (height from overlapping LoD1 building)
USES=['woonfunctie','kantoorfunctie','winkelfunctie','bijeenkomstfunctie','industriefunctie','sportfunctie',
      'onderwijsfunctie','gezondheidszorgfunctie','logiesfunctie','celfunctie','overige gebruiksfunctie']
j=gpd.overlay(bag[['identificatie','gebruiksdoel','geometry']],ex[['height','geometry']],how='intersection',keep_geom_type=True)
j['a']=j.area; hj=j.sort_values('a').groupby('identificatie').height.last()
bag['height']=bag.identificatie.map(hj).fillna(FLOOR_H)
bag['floors']=np.maximum(1,np.round(bag.height/FLOOR_H))

def cleared(g): return g.intersects(CLEAR) & (g.intersection(CLEAR).area>0.5*g.area)
KEEP_TREE_SURF=['park','edge_landscape','existing_route']
def scenario(name):
    if name=='baseline':
        return ex[['height','geometry']].copy(), trees[['height','crown','geometry']].copy(), bag.copy(), None, None
    d=D[name[-1]]; nb=d['buildings']
    b=pd.concat([ex[~cleared(ex.geometry)][['height','geometry']],nb[['height','geometry']]],ignore_index=True)
    keep_zone=d['surfaces'][d['surfaces'].surface.isin(KEEP_TREE_SURF)].union_all()
    t_ex=trees[(~trees.within(dev))|(trees.within(keep_zone))][['height','crown','geometry']]
    t_new=d['trees'].copy(); t_new['height']=(t_new.height_top_nap-3.5).round(1); t_new['crown']=2*t_new.crown_radius_m
    t=pd.concat([t_ex,t_new[['height','crown','geometry']]],ignore_index=True)
    new=nb.copy(); new['gebruiksdoel']=np.where(new.use=='residential','woonfunctie','sportfunctie'); new['floors']=np.maximum(1,np.round(new.height/FLOOR_H))
    rest=bag[~cleared(bag.geometry)][['gebruiksdoel','floors','geometry']]
    u=pd.concat([rest,new[['gebruiksdoel','floors','geometry']]],ignore_index=True)
    r=new[new.use=='residential']; pl=r.copy(); pl['gebruiksdoel']='winkelfunctie'; pl['floors']=1; rs=r.copy(); rs['floors']=rs.floors-1
    up=pd.concat([rest,new[new.use!='residential'][['gebruiksdoel','floors','geometry']],pl[['gebruiksdoel','floors','geometry']],rs[['gebruiksdoel','floors','geometry']]],ignore_index=True)
    green_site=d['surfaces'][d['surfaces'].surface.isin(['park','edge_landscape'])].union_all()
    return b,t,u,up,(green_site,d['surfaces'])
def G(x): return gpd.GeoDataFrame(x,crs=28992) if x is not None else None

# --- raster grid over study area
x0,y0,x1,y1=sa.bounds; W=int(np.ceil((x1-x0)/RES)); H=int(np.ceil((y1-y0)/RES))
TF=from_origin(x0,y1,RES,RES)
def rast(geoms,vals=None,fill=0,dtype='float32'):
    shapes=[(g,v) for g,v in zip(geoms,vals)] if vals is not None else [(g,1) for g in geoms]
    return rasterize(shapes,out_shape=(H,W),transform=TF,fill=fill,dtype=dtype,all_touched=False) if shapes else np.full((H,W),fill,dtype)
M_SA=rast([sa]).astype(bool); M_DEV=rast([dev]).astype(bool); M_W=rast([water]).astype(bool)
M_GREEN=rast([green]).astype(bool)

def svf(dsm,mask):
    """Sky view factor for a horizontal surface at observer height: SVF = 1 - mean_az sin^2(max horizon angle)."""
    z0=np.where(mask,OBS_H,np.inf).astype('float32'); acc=np.zeros((H,W),'float32')
    P=R_MAX; pad=np.pad(dsm,P,constant_values=0)
    steps=np.unique(np.r_[np.arange(1,40,1),np.arange(40,R_MAX+1,2)])
    for az in np.linspace(0,2*np.pi,N_AZ,endpoint=False):
        best=np.zeros((H,W),'float32')
        for r in steps:
            dx=int(round(r*np.sin(az)/RES)); dy=int(round(-r*np.cos(az)/RES))
            if dx==0 and dy==0: continue
            h=pad[P+dy:P+dy+H,P+dx:P+dx+W]
            np.maximum(best,(h-z0)/(np.hypot(dx,dy)*RES),out=best)
        s=np.sin(np.arctan(best)); acc+=s*s
    out=1-acc/N_AZ; out[~mask]=np.nan; return out

def entropy(u,zone):
    u=u[u.intersects(zone)].copy(); u['w']=u.intersection(zone).area*u.floors
    w={k:0.0 for k in USES}
    for g,wt in zip(u.gebruiksdoel.fillna('overige gebruiksfunctie'),u.w):
        ks=[k.strip() for k in str(g).split(',') if k.strip() in w] or ['overige gebruiksfunctie']
        for k in ks: w[k]+=wt/len(ks)
    p=np.array([v for v in w.values() if v>0]); p=p/p.sum()
    return float(-(p*np.log(p)).sum()/np.log(len(USES))), {k:round(v/sum(w.values()),3) for k,v in w.items() if v>0}

rows=[]; mixes={}
for sc in ['baseline','design_A','design_B']:
    b,t,u,up,ds=scenario(sc); b,t,u,up=G(b),G(t),G(u),G(up)
    BH=rast(b.geometry,b.height); BM=BH>0
    TC=rast(t.geometry.buffer(t.crown.values/2),t.height.values); TM=TC>0
    open_=M_SA&~BM&~M_W
    svf_b=svf(BH,open_)
    svf_bt=svf(np.maximum(BH,TC),open_)
    # H/W proxy: for open cells within 30 m of a building, H = nearest building height, W = 2*distance
    d,(iy,ix)=ndimage.distance_transform_edt(~BM,sampling=RES,return_indices=True)
    with np.errstate(divide='ignore',invalid='ignore'): hw=np.where(open_&(d<=30)&(d>0),BH[iy,ix]/(2*d),np.nan)
    for arr,nm in [(svf_bt,'svf'),(svf_b,'svfb'),(hw,'hw')]:
        with rasterio.open(f'out/{nm}_{sc}.tif','w',driver='GTiff',height=H,width=W,count=1,dtype='float32',crs='EPSG:28992',transform=TF,nodata=np.nan,compress='deflate') as f: f.write(arr.astype('float32'),1)
    for zn,zone,ZM in [('study_area',sa,M_SA),('development_site',dev,M_DEV)]:
        land=zone.difference(water); LA=land.area
        bz=b.copy(); bz['geometry']=bz.intersection(land); bz=bz[~bz.is_empty]; fa=bz.area
        gsi=fa.sum()/LA; fsi=(fa*np.maximum(1,np.round(bz.height/FLOOR_H))).sum()/LA
        hz=bz.height; wmean=np.average(hz,weights=fa) if len(hz) else 0; wstd=np.sqrt(np.average((hz-wmean)**2,weights=fa)) if len(hz) else 0
        o=ZM&open_
        tz=t[t.within(zone)]; canopy=tz.geometry.buffer(tz.crown.values/2).union_all() if len(tz) else None
        gbase=green if ds is None else green.difference(dev).union(ds[0])
        grn=gbase.union(canopy) if canopy is not None else gbase
        grn_open=grn.intersection(land).difference(b.union_all()).area/LA
        H_,mix=entropy(u,zone); mixes[(sc,zn)]=mix
        rows.append(dict(scenario=sc,zone=zn,land_area_m2=round(LA),n_buildings=int((fa>1).sum()),footprint_m2=round(fa.sum()),
            GSI=round(gsi,3),FSI=round(fsi,3),OSR=round((1-gsi)/fsi,3) if fsi else np.nan,L_avg_floors=round(fsi/gsi,1) if gsi else np.nan,
            height_mean_m=round(wmean,1),height_std_m=round(wstd,1),height_max_m=round(hz.max(),1) if len(hz) else 0,
            height_cv=round(wstd/wmean,2) if wmean else np.nan,
            SVF_mean_buildings=round(np.nanmean(svf_b[o]),3),SVF_mean=round(np.nanmean(svf_bt[o]),3),
            SVF_p10=round(np.nanpercentile(svf_bt[o],10),3),share_open_SVF_below_0_5=round(np.nanmean(svf_bt[o]<0.5),3),
            HW_median=round(np.nanmedian(hw[o]),2) if np.isfinite(hw[o]).any() else np.nan,
            green_share=round(grn_open,3),green_roof_m2=round(ds[1].loc[ds[1].surface=='green_roofs'].area.sum()) if ds is not None and zn=='development_site' else 0,landuse_mix_entropy=round(H_,3),landuse_mix_with_retail_plinth=round(entropy(up,zone)[0],3) if up is not None else round(H_,3)))
    print(sc,'done')
df=pd.DataFrame(rows); df.to_csv('out/indicators.csv',index=False)
json.dump({f'{a}|{b}':v for (a,b),v in mixes.items()},open('out/landuse_mix_shares.json','w'),indent=1)
pd.set_option('display.width',250); print(df.drop(columns=['land_area_m2']).to_string(index=False))
