import sys, numpy as np, geopandas as gpd
from lxml import etree
from shapely.geometry import Point
V='http://www.opengis.net/citygml/vegetation/2.0'; GML='http://www.opengis.net/gml'; GEN='http://www.opengis.net/citygml/generics/2.0'
rows=[]
for _,e in etree.iterparse(sys.argv[1],tag='{%s}SolitaryVegetationObject'%V):
    P=np.vstack([np.array(p.text.split(),float).reshape(-1,3) for p in e.iter('{%s}posList'%GML,'{%s}pos'%GML)]) if list(e.iter('{%s}posList'%GML,'{%s}pos'%GML)) else None
    h=e.find('{%s}height'%V); c=e.find('{%s}crownDiameter'%V)
    a={x.get('name'):x.findtext('{%s}value'%GEN) for x in e.iter('{%s}stringAttribute'%GEN)}
    if P is not None:
        rows.append(dict(tree_id=a.get('Boom_id'),species=a.get('Boomsortiment_nederlands'),height=float(h.text) if h is not None else np.nan,
                         crown=float(c.text) if c is not None else np.nan,z_base=P[:,2].min(),geometry=Point(P[:,0].mean(),P[:,1].mean())))
    e.clear()
d=gpd.GeoDataFrame(rows,crs=28992); d.to_file(sys.argv[2],layer='trees',driver='GPKG')
print(len(d),d[['height','crown']].describe().round(1).to_dict())
