import sys, numpy as np, geopandas as gpd
from lxml import etree
from shapely.geometry import Polygon
from shapely.ops import unary_union
NS={'gml':'http://www.opengis.net/gml','bldg':'http://www.opengis.net/citygml/building/2.0','core':'http://www.opengis.net/citygml/2.0'}
gml, out = sys.argv[1], sys.argv[2]
rows=[]
for _,b in etree.iterparse(gml, tag='{%s}Building'%NS['bldg']):
    if b.getparent().tag.endswith('consistsOfBuildingPart'): continue
    pts=[]; polys=[]
    for pl in b.iter('{%s}posList'%NS['gml']):
        a=np.array(pl.text.split(),float).reshape(-1,3); pts.append(a)
        if len(a)>=4:
            p=Polygon(a[:,:2])
            if p.is_valid and p.area>0.01: polys.append(p)
            elif p.buffer(0).area>0.01: polys.append(p.buffer(0))
    if not polys: b.clear(); continue
    P=np.vstack(pts); fp=unary_union([q.buffer(0.01) for q in polys]).buffer(-0.01)
    gs=[x for x in b.iter('{%s}GroundSurface'%NS['bldg'])]
    zg=min(np.array(x.text.split(),float).reshape(-1,3)[:,2].min() for g in gs for x in g.iter('{%s}posList'%NS['gml'])) if gs else P[:,2].min()
    rows.append(dict(gml_id=b.get('{%s}id'%NS['gml']), z_ground=round(zg,2), z_max=round(P[:,2].max(),2),
                     z_roof_median=round(float(np.median(P[P[:,2]>zg+1,2])) if (P[:,2]>zg+1).any() else P[:,2].max(),2), geometry=fp))
    b.clear()
d=gpd.GeoDataFrame(rows,crs=28992); d['height']=(d.z_max-d.z_ground).round(2)
d=d[d.height>1.5]; d.to_file(out,layer='buildings_lod1',driver='GPKG'); print(len(d),'buildings', d.height.describe().round(1).to_dict())
