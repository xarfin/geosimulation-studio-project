"""
CBS 2025 – Delfshaven & Schiemond
UI/UX improved version for 4.6 Socio-Demographic Data Integration.

Improvements:
- soft pastel colors without pink
- cleaner legends and labels
- Age structure shows percentages prominently, with year groups in legend
- other charts simplified for better readability in Cesium slides
- side-by-side comparison charts where useful

Keep this file in the same folder as:
CBS_4_6_Delfshaven_Schiemond.xlsx

Run:
    python generate_charts_46_pie_ux.py

Requirements:
    pip install pandas matplotlib openpyxl
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "CBS_4_6_Delfshaven_Schiemond.xlsx"
OUT = ROOT / "CBS_4_6_Results_Inside_Labels"
OUT.mkdir(exist_ok=True)

# Soft pastel palette without pink
PALETTE = [
    "#A8DADC",  # aqua
    "#F6BD60",  # soft yellow
    "#BDE0FE",  # light blue
    "#CCD5AE",  # sage
    "#CDB4DB",  # lavender
    "#DDBEA9",  # warm beige
]

plt.rcParams["font.size"] = 10
plt.rcParams["axes.titlesize"] = 14
plt.rcParams["axes.labelsize"] = 11

# ------------------------------------------------------------
# Load data
# ------------------------------------------------------------
_df = pd.read_excel(SOURCE, sheet_name="CBS_2025", engine="openpyxl")
df = _df.set_index("buurt").loc[["Delfshaven", "Schiemond"]]
for col in df.columns:
    if col not in ("cbs_code", "gemeente"):
        df[col] = pd.to_numeric(df[col], errors="coerce")


def save_table(table: pd.DataFrame, filename: str):
    table.round(2).to_csv(OUT / f"{filename}.csv", encoding="utf-8-sig")
    print(f"\nSaved table: {filename}.csv")
    print(table.round(2).to_string())


def donut_comparison(categories, labels, title, filename, colors=None, center_text=None):
    """Side-by-side pie charts: percentage and category printed INSIDE each slice."""
    if colors is None:
        colors = PALETTE[:len(labels)]

    fig, axes = plt.subplots(1, 2, figsize=(14, 7.2), subplot_kw=dict(aspect="equal"))
    for ax, buurt in zip(axes, ["Delfshaven", "Schiemond"]):
        values = df.loc[buurt, categories].tolist()
        total = sum(values)
        # Convert fractions into short explanatory labels directly inside slices.
        compact_labels = [label.replace(" households", "").replace(" housing", "") for label in labels]
        slice_labels = [f"{value/total*100:.1f}%\n({label})" for value, label in zip(values, compact_labels)]
        ax.pie(
            values,
            labels=slice_labels,
            labeldistance=0.64,
            colors=colors,
            startangle=90,
            counterclock=False,
            wedgeprops={"edgecolor": "white", "linewidth": 2},
            textprops={"fontsize": 8.6, "color": "#283944", "ha": "center", "va": "center"}
        )
        ax.set_title(buurt, pad=14, fontweight="bold")
    fig.suptitle(title, fontsize=16, fontweight="bold", y=0.98)
    fig.text(0.5, 0.055, "Source: CBS Kerncijfers wijken en buurten 2025", ha="center", fontsize=9, color="#536472")
    plt.tight_layout(rect=[0, 0.07, 1, 0.94], w_pad=3)
    plt.savefig(OUT / f"{filename}.png", dpi=220, bbox_inches="tight")
    plt.close()
    print(f"Saved chart: {filename}.png")


def horizontal_grouped_bar(table, title, filename, xlabel, colors=None, fmt="%.1f"):
    if colors is None:
        colors = PALETTE[:len(table.columns)]
    ax = table.plot.barh(figsize=(9.2, 5.5), color=colors)
    ax.set_title(title, fontsize=14, fontweight="bold", pad=15)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("")
    ax.grid(axis="x", alpha=0.2)
    ax.set_axisbelow(True)
    for c in ax.containers:
        ax.bar_label(c, fmt=fmt, padding=4, fontsize=9)
    ax.legend(title="", bbox_to_anchor=(1.02, 1), loc="upper left")
    plt.tight_layout()
    plt.savefig(OUT / f"{filename}.png", dpi=220, bbox_inches="tight")
    plt.close()
    print(f"Saved chart: {filename}.png")


def vertical_bar(table, title, filename, ylabel, colors=None, fmt="%.0f"):
    if colors is None:
        colors = [PALETTE[0], PALETTE[2]]
    ax = table.plot.bar(figsize=(7.2, 5.5), color=colors, rot=0)
    ax.set_title(title, fontsize=14, fontweight="bold", pad=15)
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", alpha=0.2)
    ax.set_axisbelow(True)
    for c in ax.containers:
        ax.bar_label(c, fmt=fmt, padding=3, fontsize=9)
    ax.legend(title="", bbox_to_anchor=(1.02, 1), loc="upper left")
    plt.tight_layout()
    plt.savefig(OUT / f"{filename}.png", dpi=220, bbox_inches="tight")
    plt.close()
    print(f"Saved chart: {filename}.png")


# ------------------------------------------------------------
# 0. Summary table for intro slide
# ------------------------------------------------------------
summary = df[["population", "population_density_per_km2", "households_total", "rental_pct"]].copy()
summary.columns = [
    "Population (people)",
    "Population density (people/km²)",
    "Households (count)",
    "Rental housing (%)"
]
save_table(summary, "00_summary")

# ------------------------------------------------------------
# 1. Age structure — percentages on chart, age ranges in legend
# ------------------------------------------------------------
age_cols = ["age_0_14", "age_15_24", "age_25_44", "age_45_64", "age_65_plus"]
age_labels = ["0–14 years", "15–24 years", "25–44 years", "45–64 years", "65+ years"]
age_table = df[age_cols].copy()
age_table.columns = age_labels
save_table(age_table, "01_age_structure_table")
donut_comparison(
    age_cols,
    age_labels,
    "Age structure",
    "01_age_structure",
    center_text="Population\nshare"
)

# ------------------------------------------------------------
# 2. Household composition — percentages on chart, household types in legend
# ------------------------------------------------------------
household_cols = ["households_single", "households_without_children", "households_with_children"]
household_labels = ["Single-person", "Without children", "With children"]
household_table = df[household_cols].copy()
household_table.columns = household_labels
save_table(household_table, "02_household_composition_table")
donut_comparison(
    household_cols,
    household_labels,
    "Household composition",
    "02_household_composition",
    center_text="Household\ntypes"
)

# ------------------------------------------------------------
# 3. Housing tenure — clean 2-part donut charts
# ------------------------------------------------------------
tenure_cols = ["owner_occupied_pct", "rental_pct"]
tenure_labels = ["Owner-occupied", "Rental"]
tenure_table = df[tenure_cols].copy()
tenure_table.columns = ["Owner-occupied housing (%)", "Rental housing (%)"]
save_table(tenure_table, "03_housing_tenure_table")
donut_comparison(
    tenure_cols,
    tenure_labels,
    "Housing tenure",
    "03_housing_tenure",
    colors=[PALETTE[0], PALETTE[3]],
    center_text="Housing\ntenure"
)

# ------------------------------------------------------------
# 4. Accessibility to services — grouped horizontal bar chart
# ------------------------------------------------------------
services = df[["distance_gp_km", "distance_supermarket_km", "distance_daycare_km", "distance_school_km"]].copy()
services.columns = [
    "GP (km)",
    "Supermarket (km)",
    "Daycare (km)",
    "Primary school (km)"
]
save_table(services, "04_accessibility_table")
horizontal_grouped_bar(
    services,
    "Accessibility to services",
    "04_accessibility",
    "Average distance (km)",
    colors=PALETTE[:4],
    fmt="%.1f"
)

# ------------------------------------------------------------
# 5. Average WOZ value — simple vertical bars
# ------------------------------------------------------------
woz = df[["avg_woz_value_thousand_eur"]].copy()
woz.columns = ["Average WOZ (€ thousand)"]
save_table(woz, "05_woz_table")
vertical_bar(
    woz,
    "Average assessed housing value (WOZ)",
    "05_woz",
    "€ thousand",
    colors=[PALETTE[1], PALETTE[1]],
    fmt="%.0f"
)

# ------------------------------------------------------------
# 6. Social assistance benefits — simple vertical bars
# ------------------------------------------------------------
benefits = df[["social_assistance_benefits"]].copy()
benefits.columns = ["Social assistance benefits (count)"]
save_table(benefits, "06_social_assistance_table")
vertical_bar(
    benefits,
    "Social assistance benefits",
    "06_social_assistance",
    "Number of benefits",
    colors=[PALETTE[4], PALETTE[4]],
    fmt="%.0f"
)

print("\nDONE — all charts and tables saved to:")
print(OUT.resolve())
